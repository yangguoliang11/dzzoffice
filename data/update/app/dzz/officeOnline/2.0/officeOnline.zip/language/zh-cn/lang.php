<?php
$lang = array
(
    'app_name'=>'OfficeOnline编辑',
    'setting'=>'设置',
    'input_officeOnline_url'=>'请输入office Online Server 地址',
    'input_officeOnline_url_notice'=>'填写您的office Online Server 地址，如:http://oos.dzz.com/',
	
	'input_dzzoffice_url'=>'请输入文件服务器地址',
    'input_officeOnline_url_notice'=>'填写您的dzzoffice地址，如:http://oos.dzz.com/。tips:输入内网地址有利于提高文件加载速度',
	
	'officeOnline_enable_failed'=>'office Online Server 地址未设置',
    'officeOnline_url_setfailed'=>'office Online Server 地址不能为空'
);
?>	